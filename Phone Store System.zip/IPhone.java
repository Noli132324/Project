// Subclass IPhone extending Phone
class IPhone extends Phone {
    public IPhone(String model, double price) {
        super("Apple", model, price);
    }

    @Override
    public String phoneType() {
        return "iPhone";
    }
}