import java.util.InputMismatchException;
import java.util.Scanner;

public class PhoneStore {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PhoneMarket market = new PhoneMarket();

        market.addPhone(new AndroidPhone("Samsung", "Galaxy S21", 899.99));
        market.addPhone(new AndroidPhone("Google", "Pixel 6", 799.99));
        market.addPhone(new AndroidPhone("Itel", "S23", 699.99));
        market.addPhone(new AndroidPhone("Vivo", "V15", 799.99));
        
        market.addPhone(new IPhone("iPhone 11", 899.99));
        market.addPhone(new IPhone("iPhone 12", 999.99));
        market.addPhone(new IPhone("iPhone 13 pro max", 110.99));
        market.addPhone(new IPhone("iPhone 14 pro max", 111.99));
        market.addPhone(new IPhone("iPhone 15 pro max", 112.99));

        boolean exit = false;

        while (!exit) {
            System.out.println("\n==== Welcome to the Phone Market! ====");
            System.out.println("1. Display available phones");
            System.out.println("2. Sell a phone");
            System.out.println("3. Add a phone");
            System.out.println("4. View sales history");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            try {
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        market.displayInventory();
                        break;
                    case 2:
                        System.out.print("Enter the index of the phone to sell: ");
                        int index = scanner.nextInt();
                        market.sellPhone(index);
                        break;
                    case 3:
                        scanner.nextLine(); // Consume newline
                        System.out.print("Enter phone brand: ");
                        String brand = scanner.nextLine();
                        System.out.print("Enter phone model: ");
                        String model = scanner.nextLine();
                        System.out.print("Enter phone price: ");
                        double price = scanner.nextDouble();

                        // Adding the new phone to the inventory
                        market.addPhone(new AndroidPhone(brand, model, price));
                        System.out.println("New phone added successfully!");
                        break;
                    case 4:
                        market.displaySalesHistory();
                        break;
                    case 5:
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a number between 1 and 5.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a valid number.");
                scanner.next(); // Clear the invalid input
            }
        }

        System.out.println("\nThank you for visiting the Phone Market!");
        scanner.close();
    }
}