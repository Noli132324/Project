import java.util.ArrayList;

public class PhoneMarket {
    private ArrayList<Phone> inventory;
    private ArrayList<Phone> soldPhones;
    private double totalMoneyEarned;

    public PhoneMarket() {
        inventory = new ArrayList<>();
        soldPhones = new ArrayList<>();
        totalMoneyEarned = 0;
    }

    public void addPhone(Phone phone) {
        inventory.add(phone);
    }

    public void displayInventory() {
        System.out.println("\n========== Available Phones ==========");
        for (int i = 0; i < inventory.size(); i++) {
            System.out.println(i + ". " + inventory.get(i));
        }
        System.out.println();
    }

    public void sellPhone(int index) {
        if (index >= 0 && index < inventory.size()) {
            Phone soldPhone = inventory.remove(index);
            soldPhones.add(soldPhone);
            totalMoneyEarned += soldPhone.getPrice();
            System.out.println("Sold: " + soldPhone);
        } else {
            System.out.println("Invalid selection!");
        }
    }

    public void displaySalesHistory() {
        System.out.println("\n========== Sales History ==========");
        for (Phone phone : soldPhones) {
            System.out.println(phone);
        }
        System.out.println("\nTotal Money Earned: $" + totalMoneyEarned);
    }
}