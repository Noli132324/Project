// Subclass AndroidPhone extending Phone
class AndroidPhone extends Phone {
    public AndroidPhone(String brand, String model, double price) {
        super(brand, model, price);
    }

    @Override
    public String phoneType() {
        return "Android Phone";
    }
}