// Abstract class for Phone
abstract class Phone {
    private String brand;
    private String model;
    private double price;

    public Phone(String brand, String model, double price) {
        this.brand = brand;
        this.model = model;
        this.price = price;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getPrice() {
        return price;
    }

    // Abstract method to be implemented in subclasses
    public abstract String phoneType();

    @Override
    public String toString() {
        return phoneType() + " - " + brand + " " + model + " - $" + price;
    }
}